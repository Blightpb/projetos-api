import type { CountryCode } from '@leandrowkz/tmdb'
import { tmdb, dispatch } from '../../src/lib/api'
import { getWatchProvidersList } from '../../src/lib/helpers'

export const config = {
  runtime: 'edge',
}

export default async (req: Request) =>
  dispatch(async () => {
    const { searchParams } = new URL(req.url)
    const showId = Number(searchParams.get('showId'))
    const country = String(
      searchParams.get('country')
    ).toUpperCase() as CountryCode

    const response = await tmdb.movies.watchProviders(showId)

    return getWatchProvidersList(response, country)
  })
